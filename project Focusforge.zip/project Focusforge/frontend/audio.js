/**
 * Web Audio API Synthesizer for FocusForge
 * Generates custom ambient noise tracks & audio feedback without relying on external files.
 */
class SoundscapeEngine {
    constructor() {
        this.ctx = null;
        this.tracks = {
            rain: { active: false, gain: null, node: null, volume: 0 },
            forest: { active: false, gain: null, node: null, volume: 0 },
            cafe: { active: false, gain: null, node: null, volume: 0 },
            ocean: { active: false, gain: null, node: null, volume: 0 },
            binaural: { active: false, gain: null, nodeLeft: null, nodeRight: null, volume: 0 }
        };
    }

    initContext() {
        if (!this.ctx) {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            this.ctx = new AudioContext();
        }
        if (this.ctx.state === 'suspended') {
            this.ctx.resume();
        }
    }

    // Helper: Create Pink/White Noise Buffer
    createNoiseBuffer() {
        const bufferSize = 2 * this.ctx.sampleRate;
        const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
        const output = buffer.getChannelData(0);
        let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
        
        for (let i = 0; i < bufferSize; i++) {
            const white = Math.random() * 2 - 1;
            b0 = 0.99886 * b0 + white * 0.0555179;
            b1 = 0.99332 * b1 + white * 0.0750759;
            b2 = 0.96900 * b2 + white * 0.1538520;
            b3 = 0.86650 * b3 + white * 0.3104856;
            b4 = 0.55000 * b4 + white * 0.5329522;
            b5 = -0.7616 * b5 - white * 0.0168980;
            output[i] = b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362;
            output[i] *= 0.11;
            b6 = white * 0.115926;
        }
        return buffer;
    }

    // Toggle Rain Track
    toggleRain(volumePct) {
        this.initContext();
        const t = this.tracks.rain;
        if (t.active && volumePct === 0) {
            t.gain.gain.linearRampToValueAtTime(0, this.ctx.currentTime + 0.5);
            setTimeout(() => { t.node.stop(); t.active = false; }, 500);
            return false;
        }

        const vol = volumePct / 100.0;
        if (!t.active) {
            const noise = this.ctx.createBufferSource();
            noise.buffer = this.createNoiseBuffer();
            noise.loop = true;

            const filter = this.ctx.createBiquadFilter();
            filter.type = 'lowpass';
            filter.frequency.value = 800;

            t.gain = this.ctx.createGain();
            t.gain.gain.value = vol;

            noise.connect(filter);
            filter.connect(t.gain);
            t.gain.connect(this.ctx.destination);

            noise.start();
            t.node = noise;
            t.active = true;
        } else {
            t.gain.gain.linearRampToValueAtTime(vol, this.ctx.currentTime + 0.1);
        }
        return true;
    }

    // Toggle Forest Wind Track
    toggleForest(volumePct) {
        this.initContext();
        const t = this.tracks.forest;
        const vol = volumePct / 100.0;

        if (t.active && volumePct === 0) {
            t.gain.gain.linearRampToValueAtTime(0, this.ctx.currentTime + 0.5);
            setTimeout(() => { t.node.stop(); t.active = false; }, 500);
            return false;
        }

        if (!t.active) {
            const noise = this.ctx.createBufferSource();
            noise.buffer = this.createNoiseBuffer();
            noise.loop = true;

            const filter = this.ctx.createBiquadFilter();
            filter.type = 'bandpass';
            filter.frequency.value = 400;
            filter.Q.value = 3.0;

            // Modulation for gentle wind breeze effect
            const lfo = this.ctx.createOscillator();
            lfo.frequency.value = 0.2;
            const lfoGain = this.ctx.createGain();
            lfoGain.gain.value = 200;
            lfo.connect(filter.frequency);
            lfo.start();

            t.gain = this.ctx.createGain();
            t.gain.gain.value = vol;

            noise.connect(filter);
            filter.connect(t.gain);
            t.gain.connect(this.ctx.destination);

            noise.start();
            t.node = noise;
            t.active = true;
        } else {
            t.gain.gain.linearRampToValueAtTime(vol, this.ctx.currentTime + 0.1);
        }
        return true;
    }

    // Toggle Ocean Waves Track
    toggleOcean(volumePct) {
        this.initContext();
        const t = this.tracks.ocean;
        const vol = volumePct / 100.0;

        if (t.active && volumePct === 0) {
            t.gain.gain.linearRampToValueAtTime(0, this.ctx.currentTime + 0.5);
            setTimeout(() => { t.node.stop(); t.active = false; }, 500);
            return false;
        }

        if (!t.active) {
            const noise = this.ctx.createBufferSource();
            noise.buffer = this.createNoiseBuffer();
            noise.loop = true;

            const filter = this.ctx.createBiquadFilter();
            filter.type = 'lowpass';
            filter.frequency.value = 300;

            const lfo = this.ctx.createOscillator();
            lfo.frequency.value = 0.1; // 10s wave cycle
            const lfoGain = this.ctx.createGain();
            lfoGain.gain.value = 250;
            lfo.connect(filter.frequency);
            lfo.start();

            t.gain = this.ctx.createGain();
            t.gain.gain.value = vol;

            noise.connect(filter);
            filter.connect(t.gain);
            t.gain.connect(this.ctx.destination);

            noise.start();
            t.node = noise;
            t.active = true;
        } else {
            t.gain.gain.linearRampToValueAtTime(vol, this.ctx.currentTime + 0.1);
        }
        return true;
    }

    // Toggle 40Hz Gamma Binaural Beats (200Hz Left, 240Hz Right)
    toggleBinaural(volumePct) {
        this.initContext();
        const t = this.tracks.binaural;
        const vol = (volumePct / 100.0) * 0.4;

        if (t.active && volumePct === 0) {
            t.gain.gain.linearRampToValueAtTime(0, this.ctx.currentTime + 0.5);
            setTimeout(() => {
                if (t.nodeLeft) t.nodeLeft.stop();
                if (t.nodeRight) t.nodeRight.stop();
                t.active = false;
            }, 500);
            return false;
        }

        if (!t.active) {
            const oscLeft = this.ctx.createOscillator();
            const oscRight = this.ctx.createOscillator();
            oscLeft.frequency.value = 200; // Base carrier
            oscRight.frequency.value = 240; // +40Hz Gamma

            const merger = this.ctx.createChannelMerger(2);
            t.gain = this.ctx.createGain();
            t.gain.gain.value = vol;

            oscLeft.connect(merger, 0, 0);
            oscRight.connect(merger, 0, 1);
            merger.connect(t.gain);
            t.gain.connect(this.ctx.destination);

            oscLeft.start();
            oscRight.start();
            t.nodeLeft = oscLeft;
            t.nodeRight = oscRight;
            t.active = true;
        } else {
            t.gain.gain.linearRampToValueAtTime(vol, this.ctx.currentTime + 0.1);
        }
        return true;
    }

    // Play Sound Effect: Start Focus Chime
    playStartChime() {
        this.initContext();
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(523.25, this.ctx.currentTime); // C5
        osc.frequency.exponentialRampToValueAtTime(659.25, this.ctx.currentTime + 0.3); // E5

        gain.gain.setValueAtTime(0.2, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.6);

        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start();
        osc.stop(this.ctx.currentTime + 0.6);
    }

    // Play Sound Effect: Session Complete Bell
    playCompletionBell() {
        this.initContext();
        const notes = [523.25, 659.25, 783.99, 1046.50]; // C, E, G, C Arpeggio
        notes.forEach((freq, idx) => {
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            osc.type = 'triangle';
            osc.frequency.value = freq;

            const startTime = this.ctx.currentTime + (idx * 0.15);
            gain.gain.setValueAtTime(0.3, startTime);
            gain.gain.exponentialRampToValueAtTime(0.001, startTime + 1.2);

            osc.connect(gain);
            gain.connect(this.ctx.destination);
            osc.start(startTime);
            osc.stop(startTime + 1.2);
        });
    }
}

// Global Sound Engine Instance
const soundEngine = new SoundscapeEngine();
