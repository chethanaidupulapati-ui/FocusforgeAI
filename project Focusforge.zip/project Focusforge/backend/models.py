from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Text, Float
from sqlalchemy.orm import relationship
from datetime import datetime, date
from database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    role = Column(String(20), default="student", nullable=False)
    username = Column(String(50), unique=True, index=True, nullable=False)
    email = Column(String(100), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    xp = Column(Integer, default=0)
    level = Column(Integer, default=1)
    streak = Column(Integer, default=0)
    best_streak = Column(Integer, default=0)
    last_focus_date = Column(String(10), nullable=True) # YYYY-MM-DD
    created_at = Column(DateTime, default=datetime.utcnow)

    tasks = relationship("Task", back_populates="owner", cascade="all, delete-orphan")
    sessions = relationship("FocusSession", back_populates="user", cascade="all, delete-orphan")
    reflections = relationship("Reflection", back_populates="user", cascade="all, delete-orphan")
    badges = relationship("UserBadge", back_populates="user", cascade="all, delete-orphan")
    roadmaps = relationship("LearningRoadmap", back_populates="user", cascade="all, delete-orphan")
    mock_tests = relationship("MockTest", back_populates="user", cascade="all, delete-orphan")


class Task(Base):
    __tablename__ = "tasks"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    title = Column(String(200), nullable=False)
    description = Column(Text, nullable=True)
    category = Column(String(50), default="Study")
    priority = Column(String(30), default="important_not_urgent") # eisenhower matrix
    difficulty = Column(String(20), default="Medium") # Easy (10 XP), Medium (25 XP), Hard (50 XP), Epic (100 XP)
    xp_reward = Column(Integer, default=25)
    completed = Column(Boolean, default=False)
    due_date = Column(String(10), nullable=True) # YYYY-MM-DD
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)

    owner = relationship("User", back_populates="tasks")


class FocusSession(Base):
    __tablename__ = "focus_sessions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    duration_minutes = Column(Integer, nullable=False)
    mode = Column(String(30), default="pomodoro") # pomodoro, short_break, long_break, deep_focus, custom
    xp_earned = Column(Integer, default=0)
    completed_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="sessions")


class Badge(Base):
    __tablename__ = "badges"

    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(50), unique=True, index=True, nullable=False)
    title = Column(String(100), nullable=False)
    description = Column(String(255), nullable=False)
    icon = Column(String(50), default="🏆")
    category = Column(String(50), default="General")

    user_badges = relationship("UserBadge", back_populates="badge")


class UserBadge(Base):
    __tablename__ = "user_badges"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    badge_id = Column(Integer, ForeignKey("badges.id"), nullable=False)
    unlocked_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="badges")
    badge = relationship("Badge", back_populates="user_badges")


class Reflection(Base):
    __tablename__ = "reflections"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    date = Column(String(10), nullable=False) # YYYY-MM-DD
    mood = Column(String(30), default="productive") # productive, energetic, tired, distracted, calm
    content = Column(Text, nullable=False)
    goals_tomorrow = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="reflections")


class LearningRoadmap(Base):
    __tablename__ = "learning_roadmaps"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    interest = Column(String(200), nullable=False)
    level = Column(String(30), default="Beginner")
    daily_minutes = Column(Integer, default=45)
    source_title = Column(String(255), nullable=True)
    source_url = Column(String(500), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="roadmaps")
    modules = relationship("RoadmapModule", back_populates="roadmap", cascade="all, delete-orphan")


class RoadmapModule(Base):
    __tablename__ = "roadmap_modules"

    id = Column(Integer, primary_key=True, index=True)
    roadmap_id = Column(Integer, ForeignKey("learning_roadmaps.id"), nullable=False)
    title = Column(String(200), nullable=False)
    description = Column(Text, nullable=True)
    order_index = Column(Integer, default=0)

    roadmap = relationship("LearningRoadmap", back_populates="modules")
    topics = relationship("RoadmapTopic", back_populates="module", cascade="all, delete-orphan")


class RoadmapTopic(Base):
    __tablename__ = "roadmap_topics"

    id = Column(Integer, primary_key=True, index=True)
    module_id = Column(Integer, ForeignKey("roadmap_modules.id"), nullable=False)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    source_url = Column(String(500), nullable=True)
    order_index = Column(Integer, default=0)
    task_id = Column(Integer, ForeignKey("tasks.id"), nullable=True)

    module = relationship("RoadmapModule", back_populates="topics")
    task = relationship("Task", foreign_keys=[task_id])


class MockTest(Base):
    __tablename__ = "mock_tests"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    roadmap_id = Column(Integer, ForeignKey("learning_roadmaps.id"), nullable=True)
    title = Column(String(200), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="mock_tests")
    questions = relationship("MockQuestion", back_populates="test", cascade="all, delete-orphan")


class MockQuestion(Base):
    __tablename__ = "mock_questions"

    id = Column(Integer, primary_key=True, index=True)
    test_id = Column(Integer, ForeignKey("mock_tests.id"), nullable=False)
    question = Column(Text, nullable=False)
    options_json = Column(Text, nullable=False)
    correct_index = Column(Integer, nullable=False)
    explanation = Column(Text, nullable=True)

    test = relationship("MockTest", back_populates="questions")
# ==================== ADMIN CONTENT SYSTEM ====================

class Subject(Base):
    __tablename__ = "subjects"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), unique=True, nullable=False)
    description = Column(Text, nullable=True)
    icon = Column(String(50), default="📚")
    published = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    topics = relationship(
        "ContentTopic",
        back_populates="subject",
        cascade="all, delete-orphan"
    )


class ContentTopic(Base):
    __tablename__ = "content_topics"

    id = Column(Integer, primary_key=True, index=True)
    subject_id = Column(Integer, ForeignKey("subjects.id"), nullable=False)
    title = Column(String(200), nullable=False)
    description = Column(Text, nullable=True)
    order_index = Column(Integer, default=0)
    published = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    subject = relationship("Subject", back_populates="topics")

    lessons = relationship(
        "ContentLesson",
        back_populates="topic",
        cascade="all, delete-orphan"
    )

    tests = relationship(
        "ContentMockTest",
        back_populates="topic",
        cascade="all, delete-orphan"
    )


class ContentLesson(Base):
    __tablename__ = "content_lessons"

    id = Column(Integer, primary_key=True, index=True)
    topic_id = Column(Integer, ForeignKey("content_topics.id"), nullable=False)
    title = Column(String(255), nullable=False)
    content = Column(Text, nullable=False)
    order_index = Column(Integer, default=0)
    estimated_minutes = Column(Integer, default=15)
    published = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    topic = relationship("ContentTopic", back_populates="lessons")


class ContentMockTest(Base):
    __tablename__ = "content_mock_tests"

    id = Column(Integer, primary_key=True, index=True)
    topic_id = Column(Integer, ForeignKey("content_topics.id"), nullable=True)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    duration_minutes = Column(Integer, default=20)
    published = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    topic = relationship("ContentTopic", back_populates="tests")

    questions = relationship(
        "ContentQuestion",
        back_populates="test",
        cascade="all, delete-orphan"
    )


class ContentQuestion(Base):
    __tablename__ = "content_questions"

    id = Column(Integer, primary_key=True, index=True)
    test_id = Column(Integer, ForeignKey("content_mock_tests.id"), nullable=False)
    question = Column(Text, nullable=False)
    options_json = Column(Text, nullable=False)
    correct_index = Column(Integer, nullable=False)
    explanation = Column(Text, nullable=True)
    order_index = Column(Integer, default=0)

    test = relationship("ContentMockTest", back_populates="questions")