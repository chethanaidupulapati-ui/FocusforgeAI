from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List
from datetime import datetime

# Auth Schemas
class UserRegister(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    email: EmailStr
    password: str = Field(..., min_length=6)

class UserLogin(BaseModel):
    username_or_email: str
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

class UserResponse(BaseModel):
    id: int
    username: str
    email: str
    xp: int
    level: int
    streak: int
    best_streak: int
    last_focus_date: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True

# Task Schemas
class TaskCreate(BaseModel):
    title: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = None
    category: str = "Study"
    priority: str = "important_not_urgent"
    difficulty: str = "Medium" # Easy, Medium, Hard, Epic
    due_date: Optional[str] = None

class TaskUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    priority: Optional[str] = None
    difficulty: Optional[str] = None
    due_date: Optional[str] = None
    completed: Optional[bool] = None

class TaskResponse(BaseModel):
    id: int
    user_id: int
    title: str
    description: Optional[str]
    category: str
    priority: str
    difficulty: str
    xp_reward: int
    completed: bool
    due_date: Optional[str]
    created_at: datetime
    completed_at: Optional[datetime]

    class Config:
        from_attributes = True

# Focus Session Schemas
class SessionCreate(BaseModel):
    duration_minutes: int = Field(..., gt=0)
    mode: str = "pomodoro"

class SessionResponse(BaseModel):
    id: int
    user_id: int
    duration_minutes: int
    mode: str
    xp_earned: int
    completed_at: datetime

    class Config:
        from_attributes = True

# Badge Schemas
class BadgeResponse(BaseModel):
    id: int
    code: str
    title: str
    description: str
    icon: str
    category: str
    unlocked: bool = False
    unlocked_at: Optional[datetime] = None

    class Config:
        from_attributes = True

# Reflection Schemas
class ReflectionCreate(BaseModel):
    date: str
    mood: str = "productive"
    content: str
    goals_tomorrow: Optional[str] = None

class ReflectionResponse(BaseModel):
    id: int
    user_id: int
    date: str
    mood: str
    content: str
    goals_tomorrow: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True

# Stats & Analytics Schema
class AnalyticsResponse(BaseModel):
    total_focus_minutes: int
    total_completed_tasks: int
    current_streak: int
    best_streak: int
    xp: int
    level: int
    xp_for_next_level: int
    level_progress_pct: float
    category_breakdown: dict
    weekly_focus_hours: List[dict]


# Learning roadmap schemas
class RoadmapGenerate(BaseModel):
    interest: str = Field(..., min_length=2, max_length=200)
    level: str = Field(default="Beginner", pattern="^(Beginner|Intermediate|Advanced)$")
    daily_minutes: int = Field(default=45, ge=15, le=480)

class RoadmapApply(BaseModel):
    interest: str = Field(..., min_length=2, max_length=200)
    level: str = Field(default="Beginner", pattern="^(Beginner|Intermediate|Advanced)$")
    daily_minutes: int = Field(default=45, ge=15, le=480)
    roadmap: dict

class MockTestRequest(BaseModel):
    interest: str = Field(..., min_length=2, max_length=200)
    level: str = Field(default="Beginner", pattern="^(Beginner|Intermediate|Advanced)$")
    count: int = Field(default=10, ge=5, le=20)
# ==================== ADMIN CONTENT SCHEMAS ====================

class SubjectCreate(BaseModel):
    name: str
    description: Optional[str] = None
    icon: str = "📚"
    published: bool = True


class SubjectUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    icon: Optional[str] = None
    published: Optional[bool] = None


class TopicCreate(BaseModel):
    subject_id: int
    title: str
    description: Optional[str] = None
    order_index: int = 0
    published: bool = True


class TopicUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    order_index: Optional[int] = None
    published: Optional[bool] = None


class LessonCreate(BaseModel):
    topic_id: int
    title: str
    content: str
    order_index: int = 0
    estimated_minutes: int = 15
    published: bool = True


class LessonUpdate(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    order_index: Optional[int] = None
    estimated_minutes: Optional[int] = None
    published: Optional[bool] = None


class ContentMockTestCreate(BaseModel):
    topic_id: Optional[int] = None
    title: str
    description: Optional[str] = None
    duration_minutes: int = 20
    published: bool = False


class ContentMockTestUpdate(BaseModel):
    topic_id: Optional[int] = None
    title: Optional[str] = None
    description: Optional[str] = None
    duration_minutes: Optional[int] = None
    published: Optional[bool] = None


class ContentQuestionCreate(BaseModel):
    test_id: int
    question: str
    options_json: str
    correct_index: int
    explanation: Optional[str] = None
    order_index: int = 0


class ContentQuestionUpdate(BaseModel):
    question: Optional[str] = None
    options_json: Optional[str] = None
    correct_index: Optional[int] = None
    explanation: Optional[str] = None
    order_index: Optional[int] = None