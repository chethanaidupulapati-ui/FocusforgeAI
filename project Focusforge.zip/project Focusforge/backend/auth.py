import os, math
from datetime import datetime, timedelta
from typing import Optional
from jose import JWTError, jwt
import bcrypt
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
import models, database

# Security settings
SECRET_KEY = os.getenv("SECRET_KEY", "focusforge_super_secret_jwt_key_2026_gamified_app")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24 * 7 # 7 days token

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")

def verify_password(plain_password: str, hashed_password: str) -> bool:
    try:
        pw_bytes = plain_password.encode('utf-8')[:72]
        return bcrypt.checkpw(pw_bytes, hashed_password.encode('utf-8'))
    except Exception:
        return False

def get_password_hash(password: str) -> str:
    pw_bytes = password.encode('utf-8')[:72]
    salt = bcrypt.gensalt()
    return bcrypt.hashpw(pw_bytes, salt).decode('utf-8')

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta if expires_delta else timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(database.get_db)
) -> models.User:

    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )

    try:
        payload = jwt.decode(
            token,
            SECRET_KEY,
            algorithms=[ALGORITHM]
        )

        user_id = payload.get("sub")

        if user_id is None:
            raise credentials_exception

        try:
            user_id = int(user_id)
        except (TypeError, ValueError):
            raise credentials_exception

    except JWTError:
        raise credentials_exception

    user = db.query(models.User).filter(
        models.User.id == user_id
    ).first()

    if user is None:
        raise credentials_exception

    return user

def calculate_level_info(xp: int):
    level = math.floor(math.sqrt(xp / 100.0)) + 1
    current_level_base_xp = (level - 1) ** 2 * 100
    next_level_xp = level ** 2 * 100
    xp_in_level = xp - current_level_base_xp
    xp_needed = next_level_xp - current_level_base_xp
    progress_pct = min(100.0, max(0.0, (xp_in_level / xp_needed) * 100.0))
    return level, current_level_base_xp, next_level_xp, progress_pct

def add_user_xp(user: models.User, xp_amount: int, db: Session):
    user.xp += xp_amount
    new_level, _, _, _ = calculate_level_info(user.xp)
    if new_level > user.level:
        user.level = new_level
    db.commit()
    db.refresh(user)
    check_and_award_badges(user, db)
    return user

def update_user_streak(user: models.User, db: Session):
    today = datetime.utcnow().strftime("%Y-%m-%d")
    yesterday = (datetime.utcnow() - timedelta(days=1)).strftime("%Y-%m-%d")
    
    if user.last_focus_date == today:
        return user.streak
        
    if user.last_focus_date == yesterday:
        user.streak += 1
    elif user.last_focus_date is None:
        user.streak = 1
    else:
        user.streak = 1

    if user.streak > user.best_streak:
        user.best_streak = user.streak

    user.last_focus_date = today
    db.commit()
    db.refresh(user)
    check_and_award_badges(user, db)
    return user.streak

def check_and_award_badges(user: models.User, db: Session):
    default_badges = [
        {"code": "first_quest", "title": "First Step", "description": "Completed your first task or quest!", "icon": "🗡️", "category": "Quests"},
        {"code": "focus_1h", "title": "Focus Novice", "description": "Logged 1 total hour of deep focus time.", "icon": "⏳", "category": "Focus"},
        {"code": "focus_10h", "title": "Focus Master", "description": "Logged 10 total hours of deep focus time!", "icon": "🎓", "category": "Focus"},
        {"code": "streak_3", "title": "Streak Ignited", "description": "Maintained a 3-day focus streak!", "icon": "🔥", "category": "Streak"},
        {"code": "streak_7", "title": "Week Warrior", "description": "Maintained a 7-day focus streak!", "icon": "⚡", "category": "Streak"},
        {"code": "level_5", "title": "Rising Star", "description": "Reached Level 5 in FocusForge.", "icon": "🌟", "category": "Level"},
        {"code": "level_10", "title": "Forge Legend", "description": "Reached Level 10 in FocusForge!", "icon": "👑", "category": "Level"},
    ]

    for bdata in default_badges:
        existing = db.query(models.Badge).filter(models.Badge.code == bdata["code"]).first()
        if not existing:
            badge_obj = models.Badge(**bdata)
            db.add(badge_obj)
            db.commit()

    unlocked_badge_ids = {ub.badge_id for ub in db.query(models.UserBadge).filter(models.UserBadge.user_id == user.id).all()}
    all_badges = {b.code: b for b in db.query(models.Badge).all()}

    def unlock(code):
        if code in all_badges:
            b_obj = all_badges[code]
            if b_obj.id not in unlocked_badge_ids:
                ub = models.UserBadge(user_id=user.id, badge_id=b_obj.id)
                db.add(ub)
                db.commit()

    completed_task_count = db.query(models.Task).filter(models.Task.user_id == user.id, models.Task.completed == True).count()
    if completed_task_count >= 1:
        unlock("first_quest")

    total_minutes = sum([s.duration_minutes for s in db.query(models.FocusSession).filter(models.FocusSession.user_id == user.id).all()])
    if total_minutes >= 60:
        unlock("focus_1h")
    if total_minutes >= 600:
        unlock("focus_10h")

    if user.streak >= 3:
        unlock("streak_3")
    if user.streak >= 7:
        unlock("streak_7")

    if user.level >= 5:
        unlock("level_5")
    if user.level >= 10:
        unlock("level_10")
# ==================== ADMIN AUTHORIZATION ====================

from fastapi import HTTPException, status


def require_admin(current_user):
    """
    Allow access only to users with the admin role.
    """
    if current_user.role != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Administrator access required"
        )

    return current_user