from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from typing import List, Optional
import os, models, schemas, database, auth
from learning_content import CATALOG, get_catalog, normalize_subject

# Always ensure database tables exist
models.Base.metadata.create_all(bind=database.engine)

# Initialize Unified FastAPI Application
app = FastAPI(
    title="FocusForge - Gamified Productivity App",
    description="Full-Stack Gamified Student Focus, Pomodoro & Quest Companion",
    version="2.5.0"
)

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ==================== AUTH ENDPOINTS ====================

@app.post("/api/auth/register", response_model=schemas.Token)
def register(user_in: schemas.UserRegister, db: Session = Depends(database.get_db)):
    if db.query(models.User).filter(models.User.username == user_in.username).first():
        raise HTTPException(status_code=400, detail="Username already registered")
    if db.query(models.User).filter(models.User.email == user_in.email).first():
        raise HTTPException(status_code=400, detail="Email already registered")

    user = models.User(
        username=user_in.username,
        email=user_in.email,
        hashed_password=auth.get_password_hash(user_in.password),
        xp=0,
        level=1,
        streak=0,
        best_streak=0
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    auth.check_and_award_badges(user, db)
    token = auth.create_access_token({"sub": str(user.id)})
    return {"access_token": token, "token_type": "bearer"}


@app.post("/api/auth/login", response_model=schemas.Token)
def login(login_in: schemas.UserLogin, db: Session = Depends(database.get_db)):
    user = db.query(models.User).filter(
        (models.User.username == login_in.username_or_email) | 
        (models.User.email == login_in.username_or_email)
    ).first()

    if not user or not auth.verify_password(login_in.password, user.hashed_password):
        raise HTTPException(status_code=400, detail="Incorrect username/email or password")

    token = auth.create_access_token({"sub": str(user.id)})
    return {"access_token": token, "token_type": "bearer"}


@app.get("/api/auth/me", response_model=schemas.UserResponse)
def get_me(current_user: models.User = Depends(auth.get_current_user)):
    return current_user


# ==================== FOCUS SESSIONS ====================

@app.post("/api/focus/session", response_model=schemas.SessionResponse)
def record_focus_session(
    session_in: schemas.SessionCreate,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(database.get_db)
):
    xp_earned = 0
    if session_in.mode in ["pomodoro", "deep_focus", "custom"]:
        xp_earned = session_in.duration_minutes * 2

    session = models.FocusSession(
        user_id=current_user.id,
        duration_minutes=session_in.duration_minutes,
        mode=session_in.mode,
        xp_earned=xp_earned
    )
    db.add(session)
    db.commit()

    if xp_earned > 0:
        auth.add_user_xp(current_user, xp_earned, db)
        auth.update_user_streak(current_user, db)

    db.refresh(session)
    return session


@app.get("/api/focus/history", response_model=List[schemas.SessionResponse])
def get_focus_history(
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(database.get_db)
):
    return db.query(models.FocusSession).filter(models.FocusSession.user_id == current_user.id).order_by(models.FocusSession.completed_at.desc()).all()


# ==================== TASKS & QUESTS ====================

@app.get("/api/tasks", response_model=List[schemas.TaskResponse])
def get_tasks(
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(database.get_db)
):
    return db.query(models.Task).filter(models.Task.user_id == current_user.id).order_by(models.Task.completed.asc(), models.Task.created_at.desc()).all()


@app.post("/api/tasks", response_model=schemas.TaskResponse)
def create_task(
    task_in: schemas.TaskCreate,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(database.get_db)
):
    difficulty_xp = {"Easy": 10, "Medium": 25, "Hard": 50, "Epic": 100}
    xp_reward = difficulty_xp.get(task_in.difficulty, 25)

    task = models.Task(
        user_id=current_user.id,
        title=task_in.title,
        description=task_in.description,
        category=task_in.category,
        priority=task_in.priority,
        difficulty=task_in.difficulty,
        xp_reward=xp_reward,
        due_date=task_in.due_date
    )
    db.add(task)
    db.commit()
    db.refresh(task)
    return task


@app.post("/api/tasks/{task_id}/complete", response_model=schemas.TaskResponse)
def toggle_task_complete(
    task_id: int,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(database.get_db)
):
    task = db.query(models.Task).filter(models.Task.id == task_id, models.Task.user_id == current_user.id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    task.completed = not task.completed
    if task.completed:
        task.completed_at = datetime.utcnow()
        auth.add_user_xp(current_user, task.xp_reward, db)
        auth.update_user_streak(current_user, db)
    else:
        task.completed_at = None

    db.commit()
    db.refresh(task)
    return task


@app.delete("/api/tasks/{task_id}")
def delete_task(
    task_id: int,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(database.get_db)
):
    task = db.query(models.Task).filter(models.Task.id == task_id, models.Task.user_id == current_user.id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    db.delete(task)
    db.commit()
    return {"message": "Task deleted"}


# ==================== LEARNING ROADMAP ====================

def _difficulty_for(level: str, module_index: int, topic_index: int) -> str:
    if level == "Beginner":
        return "Easy" if module_index == 1 else ("Medium" if module_index < 4 else "Hard")
    if level == "Intermediate":
        return "Medium" if module_index < 3 else "Hard"
    return "Hard" if module_index < 4 else "Epic"


def _build_roadmap(interest: str, level: str, daily_minutes: int):
    key, catalog = get_catalog(interest)
    if catalog is None:
        # Useful offline fallback for any subject the learner types.
        title = interest.strip().title()
        catalog = {
            "title": title,
            "summary": f"A structured study path for {title}, moving from foundations to practice and a final project.",
            "modules": [
                ("1", "Foundations", [("Core vocabulary", f"Learn the essential terms and concepts used in {title}."), ("Big picture", f"Understand the main ideas and how they connect in {title}."), ("Prerequisites", f"Review the background knowledge needed for {title}."), ("Guided practice", f"Work through introductory examples in {title}.")]),
                ("2", "Core Concepts", [("Concept 1", f"Study a central concept of {title} and explain it in your own words."), ("Concept 2", f"Practice applying another important idea from {title}."), ("Methods", f"Learn common methods used to solve problems in {title}."), ("Worked examples", f"Analyze worked examples and identify the reasoning steps.")]),
                ("3", "Application", [("Problem solving", f"Solve progressively harder problems in {title}."), ("Analysis", f"Compare approaches and explain why a solution works."), ("Practice set", f"Complete a focused practice set covering {title}."), ("Review errors", f"Identify mistakes and create corrections for weak areas.")]),
                ("4", "Mastery Project", [("Independent task", f"Complete an independent task using {title}."), ("Synthesis", f"Connect several {title} concepts in one solution."), ("Mock assessment", f"Test your knowledge under timed conditions."), ("Capstone", f"Create or solve a final project demonstrating your {title} skills.")]),
            ]
        }
    minutes_per_day = max(15, daily_minutes)
    total_subtopics = sum(len(m[2]) for m in catalog["modules"])
    # 20–45 minutes per quest depending on difficulty; scale the number of study days to the selected daily time.
    estimated_minutes = total_subtopics * (32 if level == "Beginner" else 38 if level == "Intermediate" else 45)
    weeks = max(1, (estimated_minutes + minutes_per_day * 7 - 1) // (minutes_per_day * 7))
    modules = []
    for mi, (module_id, module_title, topics) in enumerate(catalog["modules"], start=1):
        topic_items = []
        for ti, (topic_title, lesson) in enumerate(topics, start=1):
            difficulty = _difficulty_for(level, mi, ti)
            xp = {"Easy": 15, "Medium": 25, "Hard": 40, "Epic": 60}[difficulty]
            topic_items.append({
                "id": f"m{mi}t{ti}",
                "title": topic_title,
                "lesson": lesson,
                "difficulty": difficulty,
                "xp": xp,
                "estimated_minutes": 25 if difficulty == "Easy" else 35 if difficulty == "Medium" else 45 if difficulty == "Hard" else 60,
            })
        modules.append({"id": module_id, "title": module_title, "topics": topic_items})
    return {
        "subject": catalog["title"],
        "interest": interest.strip(),
        "level": level,
        "daily_minutes": daily_minutes,
        "estimated_weeks": int(weeks),
        "total_topics": total_subtopics,
        "summary": catalog["summary"],
        "modules": modules,
        "source": "FocusForge local subject curriculum",
    }


@app.post("/api/roadmap/generate")
def generate_roadmap(request: schemas.RoadmapGenerate):
    return _build_roadmap(request.interest, request.level, request.daily_minutes)


@app.post("/api/roadmap/apply")
def apply_roadmap_as_quests(
    request: schemas.RoadmapApply,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(database.get_db)
):
    roadmap = request.roadmap or _build_roadmap(request.interest, request.level, request.daily_minutes)
    created = 0
    existing_titles = {t.title for t in db.query(models.Task).filter(models.Task.user_id == current_user.id).all()}
    for module in roadmap.get("modules", []):
        for topic in module.get("topics", []):
            title = f"{roadmap.get('subject', request.interest)} · {module.get('title')} · {topic.get('title')}"
            if title in existing_titles:
                continue
            difficulty = topic.get("difficulty", "Medium")
            task = models.Task(
                user_id=current_user.id,
                title=title[:200],
                description=topic.get("lesson", "Study this topic and complete practice."),
                category="Learning",
                priority="important_not_urgent",
                difficulty=difficulty,
                xp_reward=int(topic.get("xp", 25)),
            )
            db.add(task)
            existing_titles.add(title)
            created += 1
    db.commit()
    return {"created": created, "message": f"{created} roadmap quests added to your Quest Board."}


MOCK_BANK = {
    "python": [
        ("Which Python type stores key-value pairs?", ["list", "tuple", "dict", "set"], 2, "Dictionaries map keys to values."),
        ("Which keyword defines a function in Python?", ["func", "def", "function", "lambda"], 1, "def introduces a standard named function."),
        ("What does a for loop commonly iterate over?", ["Only integers", "An iterable", "Only strings", "Only dictionaries"], 1, "for can iterate over many iterable objects."),
        ("Which block handles an exception?", ["catch", "rescue", "except", "handle"], 2, "except handles matching exceptions raised in a try block."),
        ("What does len() return for a list?", ["Its first item", "Its number of items", "Its memory size", "Its last index"], 1, "len() returns the number of elements."),
        ("Which data format is commonly parsed with json.loads()?", ["JSON text", "SQL", "HTML", "Binary only"], 0, "json.loads() parses a JSON-formatted string."),
    ],
    "javascript": [
        ("Which keyword creates a block-scoped variable that cannot be reassigned?", ["var", "let", "const", "static"], 2, "const creates a binding that cannot be reassigned."),
        ("Which method transforms every array element into a new array?", ["filter", "map", "find", "reduce"], 1, "map returns a transformed array."),
        ("Which API is commonly used for HTTP requests in modern browsers?", ["fetch", "query", "requestSQL", "browserHTTP"], 0, "fetch() provides a Promise-based HTTP interface."),
        ("What does DOM stand for?", ["Data Object Model", "Document Object Model", "Document Order Map", "Dynamic Object Manager"], 1, "DOM means Document Object Model."),
        ("Which syntax is used to wait for a Promise inside an async function?", ["pause", "wait", "await", "defer"], 2, "await pauses the async function until the Promise settles."),
    ],
    "sql": [
        ("Which clause filters rows before grouping?", ["WHERE", "GROUP", "ORDER", "HAVING"], 0, "WHERE filters rows before GROUP BY."),
        ("Which clause groups rows for aggregation?", ["SORT BY", "GROUP BY", "COLLECT", "PARTITION ONLY"], 1, "GROUP BY creates groups for aggregate calculations."),
        ("Which JOIN keeps only matching rows from both tables?", ["LEFT JOIN", "FULL JOIN", "INNER JOIN", "CROSS JOIN"], 2, "INNER JOIN returns matching rows from both sides."),
        ("Which function counts rows?", ["SUM", "COUNT", "TOTALROWS", "NUMBER"], 1, "COUNT counts rows or non-null values depending on its form."),
        ("Which command adds new rows?", ["INSERT", "APPENDROW", "CREATE", "MERGEONLY"], 0, "INSERT adds rows to a table."),
    ],
    "calculus": [
        ("What does a derivative measure?", ["Accumulated area only", "Instantaneous rate of change", "Only maximum values", "A function's domain"], 1, "A derivative represents instantaneous rate of change."),
        ("What is an antiderivative related to?", ["Differentiation", "Sorting", "Factoring only", "Probability only"], 0, "An antiderivative differentiates back to the original function."),
        ("What does a definite integral commonly represent?", ["Accumulated change", "Only a slope", "Only a limit", "A root"], 0, "Definite integrals accumulate signed quantities."),
        ("Which rule differentiates f(g(x))?", ["Power rule", "Chain rule", "Product rule", "Quotient rule"], 1, "The chain rule handles compositions."),
        ("What concept connects derivatives and definite integrals?", ["Fundamental Theorem of Calculus", "Pythagorean theorem", "Binomial theorem", "Mean value only"], 0, "The Fundamental Theorem links differentiation and integration."),
    ],
}


def _mock_questions(interest: str, count: int):
    key, _ = get_catalog(interest)
    bank = MOCK_BANK.get(key or "")
    if not bank:
        roadmap = _build_roadmap(interest, "Beginner", 45)
        generated = []
        for module in roadmap["modules"]:
            for topic in module["topics"]:
                generated.append((
                    f"Which statement best describes {topic['title']}?",
                    [topic["lesson"], "It is unrelated to the subject.", "It replaces every other concept.", "It is only a memorization exercise."],
                    0,
                    topic["lesson"]
                ))
        bank = generated
    selected = (bank * ((count + len(bank) - 1) // len(bank)))[:count]
    return [
        {"id": i + 1, "question": q, "options": opts, "answer": ans, "explanation": exp}
        for i, (q, opts, ans, exp) in enumerate(selected)
    ]


@app.post("/api/roadmap/mock-test")
def create_mock_test(request: schemas.MockTestRequest):
    roadmap = _build_roadmap(request.interest, request.level, 45)
    return {
        "subject": roadmap["subject"],
        "level": request.level,
        "questions": _mock_questions(request.interest, request.count),
    }


# ==================== BADGES & ACHIEVEMENTS ====================

@app.get("/api/badges", response_model=List[schemas.BadgeResponse])
def get_badges(
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(database.get_db)
):
    auth.check_and_award_badges(current_user, db)
    all_badges = db.query(models.Badge).all()
    user_badge_map = {ub.badge_id: ub.unlocked_at for ub in db.query(models.UserBadge).filter(models.UserBadge.user_id == current_user.id).all()}

    result = []
    for b in all_badges:
        unlocked = b.id in user_badge_map
        result.append(schemas.BadgeResponse(
            id=b.id,
            code=b.code,
            title=b.title,
            description=b.description,
            icon=b.icon,
            category=b.category,
            unlocked=unlocked,
            unlocked_at=user_badge_map.get(b.id)
        ))
    return result


# ==================== REFLECTIONS ====================

@app.get("/api/reflections", response_model=List[schemas.ReflectionResponse])
def get_reflections(
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(database.get_db)
):
    return db.query(models.Reflection).filter(models.Reflection.user_id == current_user.id).order_by(models.Reflection.date.desc()).all()


@app.post("/api/reflections", response_model=schemas.ReflectionResponse)
def create_reflection(
    ref_in: schemas.ReflectionCreate,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(database.get_db)
):
    existing = db.query(models.Reflection).filter(models.Reflection.user_id == current_user.id, models.Reflection.date == ref_in.date).first()
    if existing:
        existing.mood = ref_in.mood
        existing.content = ref_in.content
        existing.goals_tomorrow = ref_in.goals_tomorrow
        db.commit()
        db.refresh(existing)
        return existing

    reflection = models.Reflection(
        user_id=current_user.id,
        date=ref_in.date,
        mood=ref_in.mood,
        content=ref_in.content,
        goals_tomorrow=ref_in.goals_tomorrow
    )
    db.add(reflection)
    db.commit()

    auth.add_user_xp(current_user, 15, db)
    db.refresh(reflection)
    return reflection


# ==================== ANALYTICS & STATS ====================

@app.get("/api/analytics", response_model=schemas.AnalyticsResponse)
def get_analytics(
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(database.get_db)
):
    auth.check_and_award_badges(current_user, db)
    sessions = db.query(models.FocusSession).filter(models.FocusSession.user_id == current_user.id).all()
    tasks = db.query(models.Task).filter(models.Task.user_id == current_user.id).all()

    total_focus_minutes = sum([s.duration_minutes for s in sessions if s.mode in ["pomodoro", "deep_focus", "custom"]])
    total_completed_tasks = len([t for t in tasks if t.completed])
    level, current_base, next_base, progress_pct = auth.calculate_level_info(current_user.xp)

    cat_map = {}
    for t in tasks:
        if t.completed:
            cat_map[t.category] = cat_map.get(t.category, 0) + t.xp_reward

    today = datetime.utcnow().date()
    weekly_data = []
    for i in range(6, -1, -1):
        day_date = today - timedelta(days=i)
        day_str = day_date.strftime("%a")
        day_mins = sum([s.duration_minutes for s in sessions if s.completed_at and s.completed_at.date() == day_date])
        weekly_data.append({"day": day_str, "hours": round(day_mins / 60.0, 1)})

    return {
        "total_focus_minutes": total_focus_minutes,
        "total_completed_tasks": total_completed_tasks,
        "current_streak": current_user.streak,
        "best_streak": current_user.best_streak,
        "xp": current_user.xp,
        "level": level,
        "xp_for_next_level": next_base,
        "level_progress_pct": round(progress_pct, 1),
        "category_breakdown": cat_map if cat_map else {"Study": 100},
        "weekly_focus_hours": weekly_data
    }

# ==================== ADMIN CONTENT API ====================

@app.get("/api/admin/subjects")
def admin_get_subjects(
    db: Session = Depends(database.get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    auth.require_admin(current_user)

    return db.query(models.Subject).order_by(models.Subject.name).all()


@app.post("/api/admin/subjects")
def admin_create_subject(
    subject_in: schemas.SubjectCreate,
    db: Session = Depends(database.get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    auth.require_admin(current_user)

    existing = db.query(models.Subject).filter(
        models.Subject.name == subject_in.name
    ).first()

    if existing:
        raise HTTPException(
            status_code=400,
            detail="Subject already exists"
        )

    subject = models.Subject(
        name=subject_in.name,
        description=subject_in.description,
        icon=subject_in.icon,
        published=subject_in.published
    )

    db.add(subject)
    db.commit()
    db.refresh(subject)

    return subjects
@app.put("/api/admin/subjects/{subject_id}")
def admin_update_subject(
    subject_id: int,
    subject_in: schemas.SubjectUpdate,
    db: Session = Depends(database.get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    auth.require_admin(current_user)

    subject = db.query(models.Subject).filter(
        models.Subject.id == subject_id
    ).first()

    if not subject:
        raise HTTPException(status_code=404, detail="Subject not found")

    if subject_in.name is not None:
        subject.name = subject_in.name

    if subject_in.description is not None:
        subject.description = subject_in.description

    if subject_in.icon is not None:
        subject.icon = subject_in.icon

    if subject_in.published is not None:
        subject.published = subject_in.published

    db.commit()
    db.refresh(subject)

    return subject


@app.delete("/api/admin/subjects/{subject_id}")
def admin_delete_subject(
    subject_id: int,
    db: Session = Depends(database.get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    auth.require_admin(current_user)

    subject = db.query(models.Subject).filter(
        models.Subject.id == subject_id
    ).first()

    if not subject:
        raise HTTPException(status_code=404, detail="Subject not found")

    db.delete(subject)
    db.commit()

    return {"message": "Subject deleted"}
# ==================== MOUNT COMBINED FRONTEND ====================
frontend_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "frontend"))
if os.path.exists(frontend_dir):
    app.mount("/", StaticFiles(directory=frontend_dir, html=True), name="frontend")