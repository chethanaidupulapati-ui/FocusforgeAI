# FocusForge - Python Backend API

FastAPI-powered gamified student productivity backend providing authentication, focus timer sessions, Eisenhower Matrix task & quest management, leveling/XP logic, achievement badges, and analytics.

## Prerequisites
- Python 3.9+
- pip

## Quick Setup & Running

```bash
# Navigate to backend directory
cd backend

# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Windows:
venv\Scripts\activate
# On macOS/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run the FastAPI server
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

## Interactive Documentation
Once running, visit:
- **Swagger UI**: [http://localhost:8000/docs](http://localhost:8000/docs)
- **ReDoc**: [http://localhost:8000/redoc](http://localhost:8000/redoc)

## Key Endpoints
- `POST /api/auth/register` - Create new user account
- `POST /api/auth/login` - Login and acquire JWT Token
- `GET /api/auth/me` - Fetch profile, XP, Level, and Streak info
- `POST /api/focus/session` - Log completed focus session & earn XP
- `GET /api/tasks` - Retrieve task list & Eisenhower Matrix breakdown
- `POST /api/tasks` - Create new task/quest with difficulty reward
- `POST /api/tasks/{id}/complete` - Toggle completion and collect XP
- `GET /api/badges` - Fetch unlocked and locked achievement badges
- `GET /api/analytics` - Get charts and breakdown statistics
