const API_BASE_URL = 'http://localhost:8000/api';


// =========================
// AUTH
// =========================

function getToken() {
    return localStorage.getItem('ff_token');
}


function showAdminLogin() {
    document.body.innerHTML = `
        <div class="login-page">
            <div class="login-card">
                <h1>⚡ FocusForge Admin</h1>
                <p>Administrator Login</p>

                <form id="adminLoginForm">
                    <label>
                        Username or Email
                        <input
                            type="text"
                            id="adminUsername"
                            required
                            autocomplete="username"
                        >
                    </label>

                    <label>
                        Password
                        <input
                            type="password"
                            id="adminPassword"
                            required
                            autocomplete="current-password"
                        >
                    </label>

                    <button type="submit" class="primary-btn">
                        Login
                    </button>

                    <p id="loginError" class="login-error"></p>
                </form>
            </div>
        </div>
    `;

    document
        .getElementById('adminLoginForm')
        .addEventListener('submit', handleAdminLogin);
}


async function handleAdminLogin(event) {
    event.preventDefault();

    const usernameOrEmail =
        document.getElementById('adminUsername').value.trim();

    const password =
        document.getElementById('adminPassword').value;

    const errorElement =
        document.getElementById('loginError');

    errorElement.textContent = 'Logging in...';

    try {
        const response = await fetch(
            `${API_BASE_URL}/auth/login`,
            {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    username_or_email: usernameOrEmail,
                    password: password
                })
            }
        );

        const data = await response.json();

        if (!response.ok) {
            throw new Error(
                data.detail || 'Login failed'
            );
        }

        localStorage.setItem(
            'ff_token',
            data.access_token
        );

        window.location.reload();

    } catch (error) {
        console.error(error);
        errorElement.textContent = error.message;
    }
}


// =========================
// API
// =========================

async function apiRequest(
    endpoint,
    method = 'GET',
    data = null
) {
    const headers = {
        'Content-Type': 'application/json'
    };

    const token = getToken();

    if (token) {
        headers['Authorization'] =
            `Bearer ${token}`;
    }

    const options = {
        method,
        headers
    };

    if (data !== null) {
        options.body = JSON.stringify(data);
    }

    const response = await fetch(
        `${API_BASE_URL}${endpoint}`,
        options
    );

    if (!response.ok) {
        const errorText =
            await response.text();

        throw new Error(
            `${response.status}: ${errorText}`
        );
    }

    return await response.json();
}


// =========================
// PAGE STARTUP
// =========================

document.addEventListener(
    'DOMContentLoaded',
    () => {

        const token = getToken();

        if (!token) {
            showAdminLogin();
            return;
        }

        loadDashboard();

        const logoutBtn =
            document.getElementById('logoutBtn');

        if (logoutBtn) {
            logoutBtn.addEventListener(
                'click',
                () => {
                    localStorage.removeItem(
                        'ff_token'
                    );

                    window.location.reload();
                }
            );
        }
    }
);


// =========================
// DASHBOARD
// =========================

async function loadDashboard() {
    console.log('FocusForge Admin loaded');

    const subjectCount =
        document.getElementById('subjectCount');

    const topicCount =
        document.getElementById('topicCount');

    const lessonCount =
        document.getElementById('lessonCount');

    const testCount =
        document.getElementById('testCount');

    if (subjectCount) {
        subjectCount.textContent = '—';
    }

    if (topicCount) {
        topicCount.textContent = '—';
    }

    if (lessonCount) {
        lessonCount.textContent = '—';
    }

    if (testCount) {
        testCount.textContent = '—';
    }
}


// =========================
// SECTION NAVIGATION
// =========================

function openSection(section) {

    const contentArea =
        document.getElementById('contentArea');

    if (!contentArea) {
        console.error(
            'contentArea not found'
        );
        return;
    }

    if (section === 'subjects') {
        loadSubjects();
        return;
    }

    const titles = {
        topics: '🗂️ Topics',
        lessons: '📖 Lessons',
        tests: '📝 Mock Tests',
        users: '👥 Users'
    };

    contentArea.innerHTML = `
        <h2>${titles[section] || section}</h2>
        <p>
            This section will be connected
            to the FocusForge backend next.
        </p>
    `;
}


// =========================
// SUBJECTS
// =========================

async function loadSubjects() {

    const contentArea =
        document.getElementById('contentArea');

    if (!contentArea) {
        console.error(
            'contentArea not found'
        );
        return;
    }

    contentArea.innerHTML = `
        <div class="section-header">
            <div>
                <h2>📚 Subjects</h2>
                <p>
                    Manage the subjects available
                    to students.
                </p>
            </div>

            <button
                class="primary-btn"
                onclick="showCreateSubjectForm()"
            >
                + Add Subject
            </button>
        </div>

        <p>Loading subjects...</p>
    `;

    try {

        const subjects =
            await apiRequest(
                '/admin/subjects'
            );

        let html = `
            <div class="section-header">
                <div>
                    <h2>📚 Subjects</h2>
                    <p>
                        Manage the subjects available
                        to students.
                    </p>
                </div>

                <button
                    class="primary-btn"
                    onclick="showCreateSubjectForm()"
                >
                    + Add Subject
                </button>
            </div>
        `;

        if (
            !Array.isArray(subjects) ||
            subjects.length === 0
        ) {

            html += `
                <div class="empty-state">
                    <h3>No subjects yet</h3>

                    <p>
                        Create your first subject
                        to get started.
                    </p>

                    <button
                        class="primary-btn"
                        onclick="showCreateSubjectForm()"
                    >
                        + Add Subject
                    </button>
                </div>
            `;

        } else {

            html += `
                <div class="subject-list">
            `;

            subjects.forEach(subject => {

                html += `
                    <div class="subject-item">

                        <div>
                            <h3>
                                ${subject.icon || '📚'}
                                ${subject.name}
                            </h3>

                            <p>
                                ${
                                    subject.description ||
                                    'No description'
                                }
                            </p>

                            <small>
                                ${
                                    subject.published
                                        ? '🟢 Published'
                                        : '⚪ Draft'
                                }
                            </small>
                        </div>

                        <div class="subject-actions">

                            <button
                                onclick="editSubject(${subject.id})"
                            >
                                Edit
                            </button>

                            <button
                                onclick="deleteSubject(${subject.id})"
                            >
                                Delete
                            </button>

                        </div>

                    </div>
                `;
            });

            html += `</div>`;
        }

        contentArea.innerHTML = html;

    } catch (error) {

        console.error(
            'Failed to load subjects:',
            error
        );

        contentArea.innerHTML = `
            <div class="section-header">
                <div>
                    <h2>📚 Subjects</h2>
                    <p>
                        Manage the subjects available
                        to students.
                    </p>
                </div>
            </div>

            <div class="empty-state">

                <h3>
                    Unable to load subjects
                </h3>

                <p>
                    ${error.message}
                </p>

            </div>
        `;
    }
}


// =========================
// CREATE SUBJECT
// =========================

function showCreateSubjectForm() {

    const contentArea =
        document.getElementById('contentArea');

    contentArea.innerHTML = `
        <div class="section-header">
            <div>
                <h2>➕ Create Subject</h2>
                <p>
                    Add a new subject for students.
                </p>
            </div>
        </div>

        <form id="subjectForm">

            <label>
                Subject Name

                <input
                    type="text"
                    id="subjectName"
                    required
                    placeholder="e.g. Mathematics"
                >
            </label>

            <label>
                Description

                <textarea
                    id="subjectDescription"
                    placeholder="Describe this subject..."
                ></textarea>
            </label>

            <label>
                Icon

                <input
                    type="text"
                    id="subjectIcon"
                    value="📚"
                    maxlength="10"
                >
            </label>

            <label>
                <input
                    type="checkbox"
                    id="subjectPublished"
                    checked
                >

                Published
            </label>

            <button
                type="submit"
                class="primary-btn"
            >
                Create Subject
            </button>

            <button
                type="button"
                onclick="loadSubjects()"
            >
                Cancel
            </button>

        </form>
    `;

    const form =
        document.getElementById('subjectForm');

    form.addEventListener(
        'submit',
        createSubject
    );
}


async function createSubject(event) {

    event.preventDefault();

    const subject = {

        name:
            document
                .getElementById('subjectName')
                .value
                .trim(),

        description:
            document
                .getElementById('subjectDescription')
                .value
                .trim(),

        icon:
            document
                .getElementById('subjectIcon')
                .value
                .trim() || '📚',

        published:
            document
                .getElementById('subjectPublished')
                .checked
    };

    try {

        await apiRequest(
            '/admin/subjects',
            'POST',
            subject
        );

        alert(
            'Subject created successfully!'
        );

        loadSubjects();

    } catch (error) {

        console.error(error);

        alert(
            `Could not create subject: ${error.message}`
        );
    }
}


// =========================
// EDIT SUBJECT
// =========================

async function editSubject(subjectId) {

    const name =
        prompt(
            'Enter the new subject name:'
        );

    if (name === null) {
        return;
    }

    const trimmedName =
        name.trim();

    if (!trimmedName) {
        alert(
            'Subject name cannot be empty.'
        );
        return;
    }

    try {

        await apiRequest(
            `/admin/subjects/${subjectId}`,
            'PUT',
            {
                name: trimmedName
            }
        );

        alert(
            'Subject updated successfully!'
        );

        loadSubjects();

    } catch (error) {

        console.error(error);

        alert(
            `Could not update subject: ${error.message}`
        );
    }
}


// =========================
// DELETE SUBJECT
// =========================

async function deleteSubject(subjectId) {

    const confirmed =
        confirm(
            'Are you sure you want to delete this subject?'
        );

    if (!confirmed) {
        return;
    }

    try {

        await apiRequest(
            `/admin/subjects/${subjectId}`,
            'DELETE'
        );

        alert(
            'Subject deleted successfully!'
        );

        loadSubjects();

    } catch (error) {

        console.error(error);

        alert(
            `Could not delete subject: ${error.message}`
        );
    }
}