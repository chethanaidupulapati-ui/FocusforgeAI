"""Curated learning content used by FocusForge roadmaps and mock tests.

The catalog is intentionally local so the app works without an API key or network
connection. Unknown subjects receive a structured fallback roadmap.
"""

CATALOG = {
    "python": {
        "title": "Python Programming",
        "summary": "A practical path from Python fundamentals to real programs and data work.",
        "modules": [
            ("1", "Python Foundations", [
                ("Variables and Types", "Store and work with numbers, text, booleans, and None."),
                ("Operators and Expressions", "Use arithmetic, comparison, logical, and membership operators."),
                ("Conditionals", "Control program flow with if, elif, and else."),
                ("Loops", "Repeat work with for, while, range, and loop control."),
            ]),
            ("2", "Core Python", [
                ("Strings", "Manipulate text with indexing, slicing, formatting, and useful methods."),
                ("Lists and Tuples", "Store ordered collections and choose mutable or immutable structures."),
                ("Dictionaries and Sets", "Model key-value data and work with unique collections."),
                ("Functions", "Write reusable functions with parameters, return values, and scope."),
            ]),
            ("3", "Problem Solving and Code Quality", [
                ("Modules and Packages", "Split programs into reusable files and use standard libraries."),
                ("Exceptions", "Handle expected failures with try, except, else, and finally."),
                ("Files and Data", "Read and write text, CSV, and JSON data safely."),
                ("Testing and Debugging", "Use assertions, tests, tracing, and systematic debugging."),
            ]),
            ("4", "Python for Real Projects", [
                ("Object-Oriented Programming", "Model related data and behavior with classes and objects."),
                ("APIs and HTTP", "Call web APIs and understand requests, responses, and JSON."),
                ("Databases", "Connect Python applications to relational data and perform CRUD operations."),
                ("Mini Project", "Build a small useful application that combines the core skills."),
            ]),
        ]
    },
    "javascript": {
        "title": "JavaScript",
        "summary": "Learn modern JavaScript for browser applications and interactive web experiences.",
        "modules": [
            ("1", "JavaScript Foundations", [("Variables and Types", "Understand let, const, primitives, objects, and type conversion."), ("Operators", "Use arithmetic, comparison, logical, and assignment operators."), ("Conditionals", "Build decisions with if, switch, and conditional expressions."), ("Loops", "Repeat work with for, while, for...of, and array iteration.")]),
            ("2", "Functions and Data", [("Functions", "Write reusable functions and understand parameters and return values."), ("Arrays", "Transform collections with map, filter, reduce, find, and sort."), ("Objects", "Model structured data with properties, methods, and destructuring."), ("Modules", "Organize applications with import and export.")]),
            ("3", "Browser Programming", [("DOM", "Read and change page content and structure."), ("Events", "Respond to clicks, input, keyboard, and form events."), ("Async JavaScript", "Use promises and async/await for asynchronous work."), ("Fetch and APIs", "Exchange JSON data with HTTP APIs from the browser.")]),
            ("4", "Modern Web Projects", [("Forms and Validation", "Build robust interactive forms."), ("Local Storage", "Persist small amounts of browser data."), ("Debugging", "Use browser developer tools to diagnose problems."), ("Mini Project", "Build a complete interactive web application.")]),
        ]
    },
    "sql": {
        "title": "SQL and Databases",
        "summary": "Learn to query, design, and analyze relational data.",
        "modules": [
            ("1", "Relational Foundations", [("Tables and Rows", "Understand relational data and schema structure."), ("Primary Keys", "Identify rows uniquely and understand identifiers."), ("Relationships", "Model one-to-one, one-to-many, and many-to-many relationships."), ("Normalization", "Reduce duplication and improve data integrity.")]),
            ("2", "Querying Data", [("SELECT", "Retrieve columns and rows from tables."), ("Filtering", "Use WHERE, comparison, IN, LIKE, and NULL checks."), ("Sorting and Limiting", "Order and constrain result sets."), ("Aggregations", "Use COUNT, SUM, AVG, MIN, and MAX with GROUP BY.")]),
            ("3", "Combining Data", [("INNER JOIN", "Combine matching records from related tables."), ("OUTER JOINs", "Keep unmatched records when appropriate."), ("Subqueries", "Use nested queries to express multi-step logic."), ("CTEs", "Build readable multi-stage queries with WITH.")]),
            ("4", "Practical Database Work", [("INSERT UPDATE DELETE", "Change data safely."), ("Indexes", "Understand how indexes affect query performance."), ("Transactions", "Use commit and rollback for reliable changes."), ("Mini Project", "Design a small schema and answer real business questions.")]),
        ]
    },
    "data science": {
        "title": "Data Science",
        "summary": "A foundation-to-project path covering data analysis, statistics, visualization, and modeling.",
        "modules": [
            ("1", "Data Foundations", [("Data Types", "Distinguish numerical, categorical, text, time, and missing data."), ("Data Collection", "Understand datasets, sources, sampling, and data quality."), ("Cleaning", "Handle missing values, duplicates, outliers, and inconsistent formats."), ("Exploration", "Summarize a dataset before modeling.")]),
            ("2", "Statistics", [("Descriptive Statistics", "Use mean, median, spread, and distributions."), ("Probability", "Understand events, conditional probability, and independence."), ("Sampling", "Connect samples to populations and sampling error."), ("Hypothesis Testing", "Interpret hypotheses, p-values, and practical significance carefully.")]),
            ("3", "Analysis and Visualization", [("Tabular Analysis", "Group, filter, aggregate, and reshape data."), ("Charts", "Choose appropriate visualizations for different questions."), ("Correlation", "Explore relationships while avoiding causal overclaims."), ("Storytelling", "Turn analysis into clear evidence-based conclusions.")]),
            ("4", "Machine Learning Basics", [("Features and Targets", "Frame supervised learning problems."), ("Regression", "Predict continuous outcomes."), ("Classification", "Predict categories and evaluate classifiers."), ("Project", "Complete an end-to-end analysis and modeling project.")]),
        ]
    },
    "machine learning": {
        "title": "Machine Learning",
        "summary": "A practical introduction to supervised, unsupervised, and model-evaluation concepts.",
        "modules": [
            ("1", "ML Foundations", [("What is ML", "Understand learning from data and the role of features and targets."), ("Datasets", "Separate training, validation, and test data."), ("Preprocessing", "Scale, encode, clean, and transform data."), ("Overfitting", "Understand generalization, bias, variance, and regularization.")]),
            ("2", "Supervised Learning", [("Linear Regression", "Model continuous outcomes."), ("Logistic Regression", "Model probabilities for classification."), ("Decision Trees", "Learn rule-based models and tree splitting."), ("Ensembles", "Understand random forests and boosting at a high level.")]),
            ("3", "Unsupervised Learning", [("Clustering", "Group observations without labeled targets."), ("K-Means", "Learn centroid-based clustering."), ("Dimensionality Reduction", "Compress representations while preserving useful structure."), ("Evaluation", "Interpret clusters and unsupervised outputs carefully.")]),
            ("4", "ML Projects", [("Metrics", "Choose metrics such as accuracy, precision, recall, MAE, or RMSE."), ("Feature Engineering", "Create useful representations from raw data."), ("Model Comparison", "Compare models using a consistent validation setup."), ("Capstone", "Build and document an end-to-end ML workflow.")]),
        ]
    },
    "calculus": {
        "title": "Calculus",
        "summary": "A structured path through limits, derivatives, integrals, and applications.",
        "modules": [
            ("1", "Functions and Limits", [("Functions", "Understand domain, range, transformations, and composition."), ("Graphs", "Read and analyze function behavior visually."), ("Limits", "Reason about function behavior near a point."), ("Continuity", "Connect limits with continuity.")]),
            ("2", "Derivatives", [("Derivative Meaning", "Interpret rate of change and slope."), ("Derivative Rules", "Use power, product, quotient, and chain rules."), ("Implicit Differentiation", "Differentiate relationships involving multiple variables."), ("Applications", "Solve optimization and related-rate problems.")]),
            ("3", "Integrals", [("Antiderivatives", "Connect integration with reversing differentiation."), ("Definite Integrals", "Interpret accumulated change and signed area."), ("Fundamental Theorem", "Connect derivatives and definite integrals."), ("Techniques", "Use substitution and other standard integration techniques.")]),
            ("4", "Applications", [("Area", "Find areas between curves."), ("Volumes", "Use slicing and shells to find volumes."), ("Differential Equations", "Understand basic separable equations."), ("Mixed Practice", "Solve multi-step calculus problems and interpret results.")]),
        ]
    },
    "biology": {
        "title": "Biology",
        "summary": "Build a connected understanding of cells, genetics, evolution, physiology, and ecology.",
        "modules": [
            ("1", "Cell Biology", [("Cell Structure", "Compare major structures and their functions."), ("Membranes", "Understand transport and membrane organization."), ("Energy", "Connect cellular respiration and photosynthesis to energy flow."), ("Cell Division", "Understand mitosis and the cell cycle.")]),
            ("2", "Genetics", [("DNA", "Understand DNA structure and information storage."), ("Replication", "Explain how genetic information is copied."), ("Gene Expression", "Connect transcription, RNA, and translation."), ("Inheritance", "Use basic Mendelian patterns to reason about traits.")]),
            ("3", "Evolution", [("Variation", "Understand sources of variation in populations."), ("Natural Selection", "Explain selection using population-level reasoning."), ("Speciation", "Understand how populations can diverge."), ("Evidence", "Connect fossils, genetics, anatomy, and observations to evolutionary explanations.")]),
            ("4", "Ecology and Physiology", [("Ecosystems", "Trace energy and matter through ecosystems."), ("Populations", "Understand population growth and limiting factors."), ("Human Physiology", "Connect major body systems and homeostasis."), ("Review Project", "Explain a biological system using evidence and diagrams.")]),
        ]
    },
    "physics": {
        "title": "Physics",
        "summary": "Develop problem-solving skills across mechanics, energy, waves, and electricity.",
        "modules": [
            ("1", "Mechanics", [("Units and Vectors", "Use SI units, vector notation, and dimensional reasoning."), ("Kinematics", "Describe motion with position, velocity, and acceleration."), ("Forces", "Apply Newton's laws to physical situations."), ("Momentum", "Use conservation of momentum in collisions and systems.")]),
            ("2", "Energy", [("Work", "Connect force and displacement through work."), ("Kinetic Energy", "Relate motion and energy."), ("Potential Energy", "Model stored energy in physical systems."), ("Conservation", "Use energy conservation to solve multi-step problems.")]),
            ("3", "Waves and Thermal Physics", [("Oscillations", "Understand periodic motion."), ("Waves", "Relate wavelength, frequency, speed, and amplitude."), ("Sound", "Apply wave ideas to sound."), ("Thermal Physics", "Connect temperature, heat, and energy transfer.")]),
            ("4", "Electricity and Applications", [("Charge", "Understand electric charge and interaction."), ("Electric Fields", "Describe forces and fields around charges."), ("Circuits", "Use voltage, current, resistance, and simple circuit laws."), ("Mixed Practice", "Solve and explain multi-topic physics problems.")]),
        ]
    },
}

ALIASES = {
    "python programming": "python", "py": "python", "python for data science": "python",
    "js": "javascript", "web javascript": "javascript",
    "data analytics": "data science", "data analysis": "data science",
    "ml": "machine learning", "ai": "machine learning", "artificial intelligence": "machine learning",
    "math": "calculus", "mathematics": "calculus",
}


def normalize_subject(interest: str) -> str:
    key = " ".join(interest.lower().strip().split())
    return ALIASES.get(key, key)


def get_catalog(interest: str):
    key = normalize_subject(interest)
    if key in CATALOG:
        return key, CATALOG[key]
    return None, None
