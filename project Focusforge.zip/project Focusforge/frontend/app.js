/**
 * FocusForge Modern Frontend Application Logic
 * Integrates Gamification, Eisenhower Matrix Task Board, Precision Pomodoro Timer,
 * Web Audio Soundscapes, and FastAPI Backend Client with Offline Fallback.
 */

const API_BASE_URL = 'http://localhost:8000/api';

// APP STATE
const state = {
    token: localStorage.getItem('ff_token') || null,
    user: JSON.parse(localStorage.getItem('ff_user')) || {
        username: 'Hero Student',
        xp: 0,
        level: 1,
        streak: 1,
        best_streak: 1,
        last_focus_date: null
    },
    timer: {
        mode: 'pomodoro', // pomodoro, short_break, long_break, deep_focus
        durationSeconds: 25 * 60,
        remainingSeconds: 25 * 60,
        isRunning: false,
        startTime: null,
        intervalId: null,
        selectedTaskId: null
    },
    tasks: JSON.parse(localStorage.getItem('ff_tasks')) || [
        { id: 1, title: 'Complete Math Exercises Ch 4', category: 'Study', priority: 'urgent_important', difficulty: 'Medium', xp_reward: 25, completed: false },
        { id: 2, title: 'Read Research Paper on AI', category: 'Reading', priority: 'important_not_urgent', difficulty: 'Hard', xp_reward: 50, completed: false },
        { id: 3, title: 'Organize Study Desk', category: 'Personal', priority: 'neither', difficulty: 'Easy', xp_reward: 10, completed: true }
    ],
    badges: [
        { id: 1, code: 'first_quest', title: 'First Step', description: 'Completed your first task or quest!', icon: '🗡️', unlocked: true },
        { id: 2, code: 'focus_1h', title: 'Focus Novice', description: 'Logged 1 total hour of deep focus time.', icon: '⏳', unlocked: false },
        { id: 3, code: 'focus_10h', title: 'Focus Master', description: 'Logged 10 total hours of deep focus time!', icon: '🎓', unlocked: false },
        { id: 4, code: 'streak_3', title: 'Streak Ignited', description: 'Maintained a 3-day focus streak!', icon: '🔥', unlocked: true },
        { id: 5, code: 'streak_7', title: 'Week Warrior', description: 'Maintained a 7-day focus streak!', icon: '⚡', unlocked: false },
        { id: 6, code: 'level_5', title: 'Rising Star', description: 'Reached Level 5 in FocusForge.', icon: '🌟', unlocked: false }
    ],
    reflections: JSON.parse(localStorage.getItem('ff_reflections')) || []
};

// INITIALIZATION
document.addEventListener('DOMContentLoaded', () => {
    initTabs();
    initTimerControls();
    initQuestsBoard();
    initRoadmap();
    initSoundscapeControls();
    initReflectionForm();
    initAuthModals();
    updateUserHUD();
    renderTasks();
    renderBadges();
    renderAnalytics();
    populateTaskSelect();

    // Check backend connection
    if (state.token) {
        fetchUserProfile();
        fetchTasks();
    }
});

// ==================== API HELPERS ====================
async function apiRequest(endpoint, method = 'GET', data = null) {
    const headers = { 'Content-Type': 'application/json' };
    if (state.token) {
        headers['Authorization'] = `Bearer ${state.token}`;
    }
    try {
        const options = { method, headers };
        if (data) options.body = JSON.stringify(data);
        const response = await fetch(`${API_BASE_URL}${endpoint}`, options);
        if (!response.ok) throw new Error(`HTTP Error ${response.status}`);
        return await response.json();
    } catch (err) {
    console.warn(`API call failed to ${endpoint}. Using offline local state:`, err.message);
    return null;
    }
    
}

// ==================== NAVIGATION TABS ====================
function initTabs() {
    const tabBtns = document.querySelectorAll('.nav-tabs .tab-btn');
    const panels = document.querySelectorAll('.tab-panel');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const target = btn.getAttribute('data-tab');
            tabBtns.forEach(b => b.classList.remove('active'));
            panels.forEach(p => p.classList.remove('active'));

            btn.classList.add('active');
            const targetPanel = document.getElementById(`panel-${target}`);
            if (targetPanel) targetPanel.classList.add('active');

            if (target === 'analytics') renderAnalytics();
        });
    });
}

// ==================== GAMIFICATION & HUD ====================
function calculateLevelInfo(xp) {
    const level = Math.floor(Math.sqrt(xp / 100.0)) + 1;
    const currentBase = Math.pow(level - 1, 2) * 100;
    const nextBase = Math.pow(level, 2) * 100;
    const progress = Math.min(100, Math.max(0, ((xp - currentBase) / (nextBase - currentBase)) * 100));
    return { level, nextBase, progress: progress.toFixed(1) };
}

function updateUserHUD() {
    const { level, nextBase, progress } = calculateLevelInfo(state.user.xp);
    state.user.level = level;

    document.getElementById('hudStreak').textContent = state.user.streak;
    document.getElementById('hudLevelTag').textContent = `Lvl ${level}`;
    document.getElementById('hudXpFill').style.width = `${progress}%`;
    document.getElementById('hudXpText').textContent = `${state.user.xp} / ${nextBase} XP`;

    if (state.token) {
        document.getElementById('authBtnText').textContent = state.user.username;
    } else {
        document.getElementById('authBtnText').textContent = 'Login';
    }

    localStorage.setItem('ff_user', JSON.stringify(state.user));
}

function addXP(amount, reason = '') {
    const oldLevel = state.user.level;
    state.user.xp += amount;
    updateUserHUD();

    if (state.user.level > oldLevel) {
        showToast(`🎉 LEVEL UP! You reached Level ${state.user.level}!`);
        soundEngine.playCompletionBell();
    } else {
        showToast(`+${amount} XP Earned! ${reason}`);
    }

    if (state.token) {
        // Sync with backend if connected
    }
}

// ==================== DRIFT-FREE TIMER ====================
function initTimerControls() {
    const modeBtns = document.querySelectorAll('.mode-btn');
    const startBtn = document.getElementById('btnTimerStart');
    const pauseBtn = document.getElementById('btnTimerPause');
    const resetBtn = document.getElementById('btnTimerReset');

    modeBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            if (state.timer.isRunning) pauseTimer();
            modeBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            state.timer.mode = btn.getAttribute('data-mode');
            const mins = parseInt(btn.getAttribute('data-time'), 10);
            state.timer.durationSeconds = mins * 60;
            state.timer.remainingSeconds = state.timer.durationSeconds;
            updateTimerDisplay();
        });
    });

    startBtn.addEventListener('click', () => {
        if (!state.timer.isRunning) startTimer();
    });

    pauseBtn.addEventListener('click', () => {
        if (state.timer.isRunning) pauseTimer();
    });

    resetBtn.addEventListener('click', () => {
        pauseTimer();
        state.timer.remainingSeconds = state.timer.durationSeconds;
        updateTimerDisplay();
    });
}

function startTimer() {
    state.timer.isRunning = true;
    state.timer.startTime = Date.now() - ((state.timer.durationSeconds - state.timer.remainingSeconds) * 1000);

    document.getElementById('btnTimerStart').disabled = true;
    document.getElementById('btnTimerPause').disabled = false;
    document.getElementById('btnStartText').textContent = 'Focusing...';
    document.getElementById('timerStatusLabel').textContent = state.timer.mode.toUpperCase().replace('_', ' ');

    soundEngine.playStartChime();

    state.timer.intervalId = setInterval(() => {
        const elapsed = Math.floor((Date.now() - state.timer.startTime) / 1000);
        state.timer.remainingSeconds = Math.max(0, state.timer.durationSeconds - elapsed);
        updateTimerDisplay();

        if (state.timer.remainingSeconds <= 0) {
            completeTimerSession();
        }
    }, 200);
}

function pauseTimer() {
    state.timer.isRunning = false;
    clearInterval(state.timer.intervalId);

    document.getElementById('btnTimerStart').disabled = false;
    document.getElementById('btnTimerPause').disabled = true;
    document.getElementById('btnStartText').textContent = 'Resume Focus';
    document.getElementById('timerStatusLabel').textContent = 'PAUSED';
}

function updateTimerDisplay() {
    const mins = Math.floor(state.timer.remainingSeconds / 60);
    const secs = state.timer.remainingSeconds % 60;
    const timeStr = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    
    document.getElementById('timerTimeDisplay').textContent = timeStr;
    document.title = `${timeStr} - FocusForge`;

    // Circular SVG Progress Ring (dasharray = 597)
    const ring = document.getElementById('timerProgressRing');
    if (ring) {
        const pct = state.timer.remainingSeconds / state.timer.durationSeconds;
        const offset = 597 * (1 - pct);
        ring.style.strokeDashoffset = offset;
    }
}

async function completeTimerSession() {
    pauseTimer();
    soundEngine.playCompletionBell();

    const durationMins = Math.round(state.timer.durationSeconds / 60);
    let xpEarned = 0;
    
    if (['pomodoro', 'deep_focus', 'custom'].includes(state.timer.mode)) {
        xpEarned = durationMins * 2;
        addXP(xpEarned, `${durationMins}m Focus Session Completed`);
    } else {
        showToast('Break completed! Ready to focus again?');
    }

    // Call API if connected
    if (state.token) {
        await apiRequest('/focus/session', 'POST', {
            duration_minutes: durationMins,
            mode: state.timer.mode
        });
    }

    state.timer.remainingSeconds = state.timer.durationSeconds;
    updateTimerDisplay();
}

// ==================== QUEST BOARD (TASKS) ====================
function initQuestsBoard() {
    const btnList = document.getElementById('btnViewList');
    const btnMatrix = document.getElementById('btnViewMatrix');
    const listCont = document.getElementById('viewListContainer');
    const matrixCont = document.getElementById('viewMatrixContainer');
    const modal = document.getElementById('taskModal');
    const btnOpen = document.getElementById('btnOpenNewTaskModal');
    const btnClose = document.getElementById('btnCloseTaskModal');
    const btnCancel = document.getElementById('btnCancelTaskModal');
    const taskForm = document.getElementById('newTaskForm');
if (btnList && btnMatrix) {
    btnList.addEventListener('click', () => {
        btnList.classList.add('active');
        btnMatrix.classList.remove('active');
        listCont.style.display = 'block';
        matrixCont.style.display = 'none';
    });

    btnMatrix.addEventListener('click', () => {
        btnMatrix.classList.add('active');
        btnList.classList.remove('active');
        listCont.style.display = 'none';
        matrixCont.style.display = 'grid';
    });
}

    btnOpen.addEventListener('click', () => modal.classList.add('active'));
    btnClose.addEventListener('click', () => modal.classList.remove('active'));
    btnCancel.addEventListener('click', () => modal.classList.remove('active'));

    taskForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const newTask = {
            id: Date.now(),
            title: document.getElementById('taskTitle').value,
            description: document.getElementById('taskDescription').value,
            category: document.getElementById('taskCategory').value,
            difficulty: document.getElementById('taskDifficulty').value,
            priority: document.getElementById('taskPriority').value,
            due_date: document.getElementById('taskDueDate').value,
            completed: false,
            xp_reward: getDifficultyXP(document.getElementById('taskDifficulty').value)
        };

        state.tasks.unshift(newTask);
        localStorage.setItem('ff_tasks', JSON.stringify(state.tasks));
        
        renderTasks();
        populateTaskSelect();
        modal.classList.remove('active');
        taskForm.reset();
        showToast('⚔️ New Quest Forged!');

        if (state.token) {
            await apiRequest('/tasks', 'POST', newTask);
        }
    });
}

function getDifficultyXP(diff) {
    switch (diff) {
        case 'Easy': return 10;
        case 'Hard': return 50;
        case 'Epic': return 100;
        default: return 25;
    }
}

function renderTasks() {
    const grid = document.getElementById('tasksListGrid');
    const quadDo = document.getElementById('quadDoTasks');
    const quadSched = document.getElementById('quadScheduleTasks');
    const quadDeleg = document.getElementById('quadDelegateTasks');
    const quadElim = document.getElementById('quadEliminateTasks');

    grid.innerHTML = '';
    quadDo.innerHTML = '';
    quadSched.innerHTML = '';
    quadDeleg.innerHTML = '';
    quadElim.innerHTML = '';

    if (state.tasks.length === 0) {
        grid.innerHTML = '<p class="text-muted">No quests active. Click + Add New Quest to start!</p>';
        return;
    }

    state.tasks.forEach(t => {
        const card = createTaskCardElement(t);
        grid.appendChild(card);

        // Eisenhower Matrix routing
        const clone = card.cloneNode(true);
        attachCardListeners(clone, t);
        if (t.priority === 'urgent_important') quadDo.appendChild(clone);
        else if (t.priority === 'important_not_urgent') quadSched.appendChild(clone);
        else if (t.priority === 'urgent_not_important') quadDeleg.appendChild(clone);
        else quadElim.appendChild(clone);
    });
}

function createTaskCardElement(t) {
    const card = document.createElement('div');
    card.className = `task-card ${t.completed ? 'completed' : ''}`;
    card.innerHTML = `
        <div class="task-header-row">
            <h4 class="task-title">${t.title}</h4>
            <div class="task-tags">
                <span class="badge-tag badge-category">${t.category}</span>
                <span class="badge-tag badge-${t.difficulty.toLowerCase()}">${t.difficulty}</span>
            </div>
        </div>
        ${t.description ? `<p style="font-size:12px; color:var(--text-secondary);">${t.description}</p>` : ''}
        <div class="task-footer">
            <span class="task-xp-value">⭐ +${t.xp_reward} XP</span>
            <button class="btn-checkbox">${t.completed ? '✓ Done' : 'Complete Quest'}</button>
        </div>
    `;
    attachCardListeners(card, t);
    return card;
}

function attachCardListeners(card, t) {
    const btn = card.querySelector('.btn-checkbox');
    btn.addEventListener('click', async () => {
        t.completed = !t.completed;
        localStorage.setItem('ff_tasks', JSON.stringify(state.tasks));

        if (t.completed) {
            addXP(t.xp_reward, `Quest "${t.title}" completed`);
            soundEngine.playStartChime();
        }

        renderTasks();

        if (state.token) {
            await apiRequest(`/tasks/${t.id}/complete`, 'POST');
        }
    });
}

function populateTaskSelect() {
    const select = document.getElementById('currentTaskSelect');
    select.innerHTML = '<option value="">-- Select an active quest (Optional) --</option>';
    state.tasks.filter(t => !t.completed).forEach(t => {
        const opt = document.createElement('option');
        opt.value = t.id;
        opt.textContent = `${t.title} (+${t.xp_reward} XP)`;
        select.appendChild(opt);
    });
}


// ==================== PERSONALIZED LEARNING ROADMAP ====================
let currentRoadmap = null;

function escapeHTML(value) {
    return String(value ?? '').replace(/[&<>'"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch]));
}

function initRoadmap() {
    const form = document.getElementById('roadmapForm');
    const generateBtn = document.getElementById('btnGenerateRoadmap');
    const mockBtn = document.getElementById('btnCreateMockTest');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const interest = document.getElementById('roadmapInterest').value.trim();
        const level = document.getElementById('roadmapLevel').value;
        const daily_minutes = Number(document.getElementById('roadmapMinutes').value);
        if (!interest) return;

        setRoadmapStatus('Building your curriculum and quests…', 'loading');
        generateBtn.disabled = true;
        const roadmap = await apiRequest('/roadmap/generate', 'POST', { interest, level, daily_minutes });
        generateBtn.disabled = false;

        if (!roadmap) {
            setRoadmapStatus('Could not reach the learning backend. Make sure the FastAPI server is running on port 8000.', 'error');
            return;
        }

        currentRoadmap = roadmap;
        localStorage.setItem('ff_roadmap', JSON.stringify(roadmap));
        renderRoadmap(roadmap);
        mockBtn.disabled = false;

        if (state.token) {
            const applied = await apiRequest('/roadmap/apply', 'POST', { interest, level, daily_minutes, roadmap });
            if (applied) {
                setRoadmapStatus(`Roadmap ready — ${roadmap.total_topics} learning quests created. ${applied.created} new quests were added to your Quest Board.`, 'success');
                await fetchTasks();
            } else {
                setRoadmapStatus(`Roadmap ready — ${roadmap.total_topics} topics across ${roadmap.modules.length} modules.`, 'success');
            }
        } else {
            setRoadmapStatus(`Roadmap ready — ${roadmap.total_topics} topics across ${roadmap.modules.length} modules. Log in to save every topic as backend quests.`, 'success');
        }
    });

    mockBtn.addEventListener('click', async () => {
        if (!currentRoadmap) return;
        mockBtn.disabled = true;
        const result = await apiRequest('/roadmap/mock-test', 'POST', {
            interest: currentRoadmap.interest,
            level: currentRoadmap.level,
            count: 10
        });
        mockBtn.disabled = false;
        if (!result) {
            document.getElementById('mockTestResult').innerHTML = '<div class="roadmap-error">Mock test could not be loaded.</div>';
            return;
        }
        renderMockTest(result);
    });

    const saved = localStorage.getItem('ff_roadmap');
    if (saved) {
        try {
            currentRoadmap = JSON.parse(saved);
            renderRoadmap(currentRoadmap);
            mockBtn.disabled = false;
            setRoadmapStatus('Saved roadmap restored from this browser.', 'success');
        } catch (_) {}
    }
}

function setRoadmapStatus(message, type='') {
    const el = document.getElementById('roadmapStatus');
    if (el) {
        el.className = `roadmap-status ${type}`;
        el.textContent = message;
    }
}

function renderRoadmap(roadmap) {
    const result = document.getElementById('roadmapResult');
    if (!result) return;
    result.innerHTML = `
        <div class="roadmap-overview">
            <div><span class="roadmap-kicker">LEARNING PATH</span><h3>${escapeHTML(roadmap.subject)}</h3><p>${escapeHTML(roadmap.summary)}</p></div>
            <div class="roadmap-stats">
                <span>📚 ${roadmap.modules.length} modules</span>
                <span>🧩 ${roadmap.total_topics} quests</span>
                <span>⏱️ ${roadmap.daily_minutes} min/day</span>
                <span>🗓️ ~${roadmap.estimated_weeks} weeks</span>
            </div>
        </div>
        <div class="roadmap-modules">
            ${roadmap.modules.map((module, index) => `
                <article class="roadmap-module">
                    <div class="module-heading">
                        <span class="module-number">${index + 1}</span>
                        <div><h4>${escapeHTML(module.title)}</h4><span>${module.topics.length} quests</span></div>
                    </div>
                    <div class="roadmap-topics">
                        ${module.topics.map(topic => `
                            <div class="roadmap-topic-card">
                                <div class="topic-topline">
                                    <strong>${escapeHTML(topic.title)}</strong>
                                    <span class="topic-xp">+${topic.xp} XP</span>
                                </div>
                                <p>${escapeHTML(topic.lesson)}</p>
                                <div class="topic-meta"><span>${escapeHTML(topic.difficulty)}</span><span>⏱ ${topic.estimated_minutes} min</span></div>
                            </div>
                        `).join('')}
                    </div>
                </article>
            `).join('')}
        </div>`;
}

function renderMockTest(test) {
    const result = document.getElementById('mockTestResult');
    result.innerHTML = `
        <div class="mock-test-header"><h3>📝 ${escapeHTML(test.subject)} Mock Test</h3><span>${test.questions.length} questions</span></div>
        <div class="mock-questions">
            ${test.questions.map((q, idx) => `
                <div class="mock-question" data-answer="${q.answer}">
                    <h4>${idx + 1}. ${escapeHTML(q.question)}</h4>
                    <div class="mock-options">
                        ${q.options.map((option, oi) => `<button type="button" class="mock-option" data-index="${oi}">${escapeHTML(option)}</button>`).join('')}
                    </div>
                    <div class="mock-explanation" hidden>${escapeHTML(q.explanation)}</div>
                </div>
            `).join('')}
        </div>
        <button type="button" class="btn-primary mock-submit" id="btnGradeMock">Grade Test</button>
        <div id="mockScore" class="mock-score"></div>
    `;

    result.querySelectorAll('.mock-option').forEach(btn => {
        btn.addEventListener('click', () => {
            const parent = btn.closest('.mock-question');
            parent.querySelectorAll('.mock-option').forEach(b => b.classList.remove('selected'));
            btn.classList.add('selected');
        });
    });

    document.getElementById('btnGradeMock').addEventListener('click', () => {
        let score = 0;
        const questions = result.querySelectorAll('.mock-question');
        questions.forEach(q => {
            const answer = Number(q.dataset.answer);
            const selected = q.querySelector('.mock-option.selected');
            q.querySelectorAll('.mock-option').forEach((btn, index) => {
                btn.classList.remove('correct', 'wrong');
                if (index === answer) btn.classList.add('correct');
            });
            if (selected && Number(selected.dataset.index) === answer) score++;
            else if (selected) selected.classList.add('wrong');
            q.querySelector('.mock-explanation').hidden = false;
        });
        const pct = Math.round((score / questions.length) * 100);
        document.getElementById('mockScore').textContent = `Score: ${score}/${questions.length} (${pct}%)`;
    });
}

// ==================== AMBIENT SOUNDSCAPE CONTROLS ====================
function initSoundscapeControls() {
    setupSoundTrack('Rain', (vol) => soundEngine.toggleRain(vol));
    setupSoundTrack('Forest', (vol) => soundEngine.toggleForest(vol));
    setupSoundTrack('Cafe', (vol) => soundEngine.toggleForest(vol));
    setupSoundTrack('Ocean', (vol) => soundEngine.toggleOcean(vol));
    setupSoundTrack('Binaural', (vol) => soundEngine.toggleBinaural(vol));
}

function setupSoundTrack(name, toggleFn) {
    const slider = document.getElementById(`vol${name}`);
    const btn = document.getElementById(`btnToggle${name}`);

    slider.addEventListener('input', () => {
        const vol = parseInt(slider.value, 10);
        const playing = toggleFn(vol);
        if (vol > 0 && playing) {
            btn.classList.add('playing');
            btn.textContent = 'Pause';
        } else {
            btn.classList.remove('playing');
            btn.textContent = 'Play';
        }
    });

    btn.addEventListener('click', () => {
        if (slider.value == 0) slider.value = 50;
        else slider.value = 0;
        slider.dispatchEvent(new Event('input'));
    });
}

// ==================== REFLECTION & JOURNAL ====================
function initReflectionForm() {
    const form = document.getElementById('reflectionForm');
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const mood = document.querySelector('input[name="mood"]:checked').value;
        const content = document.getElementById('reflectionContent').value;
        const goals = document.getElementById('reflectionGoals').value;

        const ref = {
            id: Date.now(),
            date: new Date().toISOString().split('T')[0],
            mood, content, goals_tomorrow: goals
        };

        state.reflections.unshift(ref);
        localStorage.setItem('ff_reflections', JSON.stringify(state.reflections));

        addXP(15, 'Daily Reflection Saved!');
        form.reset();

        if (state.token) {
            await apiRequest('/reflections', 'POST', ref);
        }
    });
}

// ==================== BADGES & ANALYTICS ====================
function renderBadges() {
    const grid = document.getElementById('badgesGrid');
    grid.innerHTML = '';
    state.badges.forEach(b => {
        const card = document.createElement('div');
        card.className = `badge-card ${b.unlocked ? 'unlocked' : ''}`;
        card.innerHTML = `
            <div class="badge-icon">${b.icon}</div>
            <div class="badge-title">${b.title}</div>
            <div class="badge-desc">${b.description}</div>
        `;
        grid.appendChild(card);
    });
}

function renderAnalytics() {
    const completedTasks = state.tasks.filter(t => t.completed).length;
    document.getElementById('statCompletedQuests').textContent = completedTasks;
    document.getElementById('statBestStreak').textContent = `${state.user.best_streak} Days`;
    document.getElementById('statTotalXp').textContent = `${state.user.xp} XP`;

    // Render Weekly Bar Chart
    const chartContainer = document.getElementById('weeklyChart');
    const sampleDays = [
        { day: 'Mon', hours: 1.5 },
        { day: 'Tue', hours: 2.0 },
        { day: 'Wed', hours: 3.5 },
        { day: 'Thu', hours: 2.5 },
        { day: 'Fri', hours: 4.0 },
        { day: 'Sat', hours: 1.0 },
        { day: 'Sun', hours: 2.8 }
    ];

    chartContainer.innerHTML = '';
    const maxH = 5.0;
    sampleDays.forEach(d => {
        const pct = Math.min(100, (d.hours / maxH) * 100);
        const col = document.createElement('div');
        col.className = 'bar-col';
        col.innerHTML = `
            <span style="font-size:10px; color:var(--text-muted);">${d.hours}h</span>
            <div class="bar-fill" style="height: ${pct}%;"></div>
            <span class="bar-label">${d.day}</span>
        `;
        chartContainer.appendChild(col);
    });
}

// ==================== AUTHENTICATION MODAL ====================
function initAuthModals() {
    const btnOpen = document.getElementById('btnAuthModal');
    const modal = document.getElementById('authModal');
    const btnClose = document.getElementById('btnCloseAuthModal');
    const tabLogin = document.getElementById('authTabLogin');
    const tabRegister = document.getElementById('authTabRegister');
    const formLogin = document.getElementById('loginForm');
    const formReg = document.getElementById('registerForm');

    btnOpen.addEventListener('click', () => modal.classList.add('active'));
    btnClose.addEventListener('click', () => modal.classList.remove('active'));

    tabLogin.addEventListener('click', () => {
        tabLogin.classList.add('active');
        tabRegister.classList.remove('active');
        formLogin.style.display = 'block';
        formReg.style.display = 'none';
    });

    tabRegister.addEventListener('click', () => {
        tabRegister.classList.add('active');
        tabLogin.classList.remove('active');
        formReg.style.display = 'block';
        formLogin.style.display = 'none';
    });

    formLogin.addEventListener('submit', async (e) => {
        e.preventDefault();
        const username = document.getElementById('loginUsername').value;
        const pass = document.getElementById('loginPassword').value;

        const res = await apiRequest('/auth/login', 'POST', { username_or_email: username, password: pass });
        if (res && res.access_token) {
            state.token = res.access_token;
            localStorage.setItem('ff_token', res.access_token);
            await fetchUserProfile();
            modal.classList.remove('active');
            showToast(`Welcome back, ${state.user.username}!`);
        } else {
            showToast('Offline Mode Activated. Logged in locally.');
            state.user.username = username;
            updateUserHUD();
            modal.classList.remove('active');
        }
    });

    formReg.addEventListener('submit', async (e) => {
        e.preventDefault();

        const username = document.getElementById('regUsername').value.trim();
        const email = document.getElementById('regEmail').value.trim();
        const password = document.getElementById('regPassword').value;

        const res = await apiRequest('/auth/register', 'POST', {
            username: username,
            email: email,
            password: password
        });

        if (res && res.access_token) {
            state.token = res.access_token;
            localStorage.setItem('ff_token', res.access_token);

            await fetchUserProfile();

            modal.classList.remove('active');
            showToast(`Welcome to FocusForge, ${username}!`);
        } else {
            showToast('Registration failed. Please check your details.');
        }
    });
}

async function fetchUserProfile() {
    const profile = await apiRequest('/auth/me');
    if (profile) {
        state.user = profile;
        updateUserHUD();
    }
}

async function fetchTasks() {
    const tasks = await apiRequest('/tasks');
    if (tasks && tasks.length > 0) {
        state.tasks = tasks;
        renderTasks();
        populateTaskSelect();
    }
}

// ==================== TOAST NOTIFICATIONS ====================
function showToast(msg) {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<span>⚡</span> <span>${msg}</span>`;
    container.appendChild(toast);
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 300);
    }, 3500);
}
document.addEventListener('DOMContentLoaded', () => {
    const formReg = document.getElementById('registerForm');

    if (formReg) {
        formReg.addEventListener('submit', async (e) => {
            e.preventDefault();

            const username = document.getElementById('regUsername').value.trim();
            const email = document.getElementById('regEmail').value.trim();
            const password = document.getElementById('regPassword').value;

            console.log('Sending registration request...');

            const res = await apiRequest('/auth/register', 'POST', {
                username: username,
                email: email,
                password: password
            });

            console.log('Registration response:', res);

            if (res && res.access_token) {
                state.token = res.access_token;
                localStorage.setItem('ff_token', res.access_token);

                await fetchUserProfile();

                const modal = document.getElementById('authModal');
                if (modal) modal.classList.remove('active');

                showToast(`Welcome to FocusForge, ${username}!`);
            } else {
                showToast('Registration failed. Please check your details.');
            }
        });
    }
});
